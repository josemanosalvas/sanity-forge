# groq-compiler

Compiles Sanity GROQ queries to the smallest equivalent query. Keep writing readable, modular queries
(fragments interpolated into a page query); the compiler minifies them, removes redundant syntax, shares
repeated projections as custom GROQ functions, and proves with [groq-js](https://github.com/sanity-io/groq-js)
that the result means the same thing. It also splits page-builder queries per block type so each fits the GET
budget of `@sanity/client`, and shrinks the types Sanity TypeGen generates.

```js
import { compile } from "groq-compiler/verify";

const { query, functions, report, fallback } = compile(pageQuery);
// sanity-forge's pageQuery: 18,809 bytes as written → 11,410 (defaults) → 4,340 bytes with
// { share: "with-params", nested: true }; groq-js parses original and output to the same tree.
```

Version 0.1.0, not yet published to npm. Until then, install a tarball built with `npm pack`.
Node 22.12 or later; ESM only.

## Entry points

| Entry point            | Contents                                                                                                | Dependencies                          |
| ---------------------- | ------------------------------------------------------------------------------------------------------- | ------------------------------------- |
| `groq-compiler`        | `minify(query)`, `compile(query, options)`                                                              | none                                  |
| `groq-compiler/verify` | `compile` that verifies by default, `oracle`, `sameTree`, `sameResults`, `checkSanityRules`             | `groq-js` (optional peer)             |
| `groq-compiler/budget` | `encodeQueryString`, `encodedQueryLength`, `requestMethod`, `GET_QUERY_LIMIT`, `budget`, `formatBudget` | none                                  |
| `groq-compiler/split`  | `split`, `stitch`, `neededQueries`, `fetchSplit`, `splitBudget`, `toPlan`                               | none                                  |
| `groq-compiler/types`  | `dedupeTypes`, `generateAssignabilityCheck`, `loadTypeScript`                                           | `typescript` 5.9 or 6 (optional peer) |
| `groq-compiler/sanity` | `compileRegistry`, `compiledQueriesModule`, `withCompiledQueries`, `compiledQuery`, `readQueryRegistry` | none                                  |

## compile

```ts
compile(query: string, options?: CompileOptions): {
  query: string;              // the compiled query
  functions: SharedFunction[]; // custom functions the share pass declared
  report: CompileReport;      // bytes after each pass, skipped candidates by reason, verification
  fallback?: Fallback;        // present when compilation stopped early
}
```

| Option   | Default                               | Meaning                                                                                                                                          |
| -------- | ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| `tidy`   | `true`                                | Drop trailing commas; write `"x": x` and `"x": x->` as `x` and `x->`                                                                             |
| `share`  | `"documented"`                        | Share repeated projections as functions. `"documented"` keeps bodies free of query parameters; `"with-params"` lets them read `$params`; `"off"` |
| `nested` | `false`                               | Let function bodies call custom functions (generated or existing)                                                                                |
| `cost`   | `"bytes"`                             | Minimise UTF-8 bytes, or `"url"`: the URL-encoded length `@sanity/client` sends with GET                                                         |
| `mangle` | `false`                               | Rename every custom function, existing ones included, and their parameters to short names                                                        |
| `verify` | `"tree"` with an oracle, else `"off"` | Prove the output with the oracle; fall back to the minified query on a mismatch                                                                  |
| `oracle` | none (set by `groq-compiler/verify`)  | groq-js `parse`, injected so the core stays dependency-free                                                                                      |

The defaults use only behaviour Sanity documents. `share: "with-params"` and `nested: true` rely on behaviour the
docs neither allow nor forbid; both passed on the real API (see [findings](docs/findings.md)).

Guarantees:

- `compile` never throws on valid GROQ. Input it cannot parse, syntax it does not model, or output the oracle
  rejects yields the minified query and a `fallback` with the reason; the report names shared functions the
  oracle rejects on their own.
- It throws only what `minify` throws: `SyntaxError` for unterminated strings and invalid escapes (with a
  zero-based UTF-8 byte offset) and `TypeError` for non-strings and unpaired UTF-16 surrogates.
- Generated functions follow Sanity's rules: one parameter used once, bodies `$p{…}`, `$p->{…}`, `$p[]{…}` or
  `$p[]->{…}`, no `^`, no recursion, callees declared before callers, explicit keys where a call replaces a
  shorthand member. Existing declarations stay untouched (unless `mangle`); unused ones are removed.

`minify` keeps groq-minifier's contract exactly: comments and redundant whitespace go, the spelling of every
token stays, output never grows and is idempotent.

## How it is proven

groq-js 2.0.0 expands custom functions while parsing, so "original and compiled parse to the same tree" proves
equal results on every dataset under groq-js semantics. The share pass decides legality with a port of groq-js's
tree builder on each traversal chain (projections over traversals, pipes, parentheses, results traversed further),
then `verify: "tree"` checks the whole output with groq-js itself. Tests also compare results on sanity-forge's
seed dataset, and `checkSanityRules` enforces the rules groq-js does not.

## Budget

`@sanity/client` sends a query as GET only when its URL-encoded `{ query, params }` is shorter than 11,264
characters. Only tokenless GET requests reach Sanity's global edge cache.

```js
import { requestMethod, encodedQueryLength } from "groq-compiler/budget";
requestMethod(query, { site: "brand-a" }); // "GET" | "POST"
```

## Split

```js
import { split, toPlan, fetchSplit } from "groq-compiler/split";

const plan = toPlan(split(pageQuery, { compile: { share: "with-params", nested: true } }));
// At runtime: the outline, then only the block queries the page needs, in parallel, stitched into
// exactly the monolithic result. Falls back to pageQuery if content changed between requests.
const page = await fetchSplit(
  plan,
  (query, params) => client.fetch(query, params),
  params,
  pageQuery,
);
```

The outline holds the page fields and `_key`/`_type` for every block, container children included. Each block
query keeps the page projection around its list so `^` keeps its scope, and drops branches that cannot apply to
its type (`==`, `!=`, `in`, `match` groups, combined `||` conditions). Containers (a branch holding another
`_type` list) are split again when configured or, with `containers: "auto"`, when their query is over budget.

## Types

```js
import { dedupeTypes } from "groq-compiler/types";
const { output, aliases } = await dedupeTypes(readFileSync("sanity.types.ts", "utf8"));
```

Each repeated object type becomes one non-exported alias named after its `_type` or property path, so
regenerated files change few names. Exported names and types stay the same; `generateAssignabilityCheck`
produces the files that prove it. TypeScript 7 has no JavaScript compiler API, so this entry needs TypeScript
5.9 or 6 (pass `options.ts` or install it). A 5 MB TypeGen file shrank to 998 KB, and type-checking used a
fifth of the memory.

## Sanity

Build time: compile TypeGen's query registry into a module.

```sh
groq-compiler typegen src/sanity.types.ts --out src/compiled-queries.ts --share with-params --nested
groq-compiler typegen src/sanity.types.ts --out src/compiled-queries.ts --share with-params --nested --check
```

Runtime: send the compiled text in place of each original; TypeGen's result types stay keyed by the original.

```ts
import { withCompiledQueries } from "groq-compiler/sanity";
import { compiledQueries } from "./compiled-queries";

export const sanityFetch = withCompiledQueries(live.sanityFetch, compiledQueries);
```

## Command line

```text
groq-compiler compile [file]                 compile a query (file or stdin)
groq-compiler budget <sanity.types.ts>       every TypeGen query as GET or POST, with its margin
groq-compiler split <file> [--query NAME]    per-block-type queries and their budget
groq-compiler dedupe-types <sanity.types.ts> [--out file]
groq-compiler typegen <sanity.types.ts> --out <file> [--check]
```

Compile flags: `--share`, `--nested`, `--cost`, `--mangle`, `--no-tidy`, `--no-verify`. Run with `--help` for
the rest. The CLI verifies with groq-js when it is installed.

## Development

```sh
npm ci
npm run build
npm run check   # tsc, oxlint, oxfmt
npm test        # vitest
```

- `fixtures/cases.json` and `fixtures/benchmarks.json` come from groq-minifier. `fixtures/sanity-forge/` holds
  sanity-forge's TypeGen registry and seed dataset; refresh them with `node scripts/sync-sanity-forge.mjs`
  after `npm run build`.
- The differential test compares `minify` with groq-minifier's Rust crate on 300,000 generated inputs. It needs
  `cargo` and a groq-minifier checkout (`GROQ_MINIFIER_DIR`, default `../groq-minifier`) and skips with a message
  otherwise.
- Tests over a private corpus run when `GROQ_COMPILER_PRIVATE_CORPUS` points at a TypeGen file; keep such files,
  and anything derived from them except aggregate numbers, outside this repository.
- `node scripts/measure-types.mjs <sanity.types.ts>` reports type deduplication sizes and `tsc
  --extendedDiagnostics` numbers for TypeScript 5.9 and 7.

[docs/findings.md](docs/findings.md) records the measurements and Sanity platform facts behind every decision;
[PLAN.md](PLAN.md) is the implementation plan.

## License

MIT
